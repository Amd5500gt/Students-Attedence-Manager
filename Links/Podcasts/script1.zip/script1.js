// Generate Resume
function generateResume() {
  // Populate preview with form data
  document.getElementById('preview-full-name').innerText = document.getElementById('full-name').value;
  document.getElementById('preview-dob').innerText = document.getElementById('dob').value;
  document.getElementById('preview-email').innerText = document.getElementById('email').value;
  document.getElementById('preview-phone').innerText = document.getElementById('phone').value;
  document.getElementById('preview-address').innerText = document.getElementById('address').value;
  document.getElementById('preview-school').innerText = document.getElementById('school').value;
  document.getElementById('preview-degree').innerText = document.getElementById('degree').value;
  document.getElementById('preview-graduation-year').innerText = document.getElementById('year').value;
  document.getElementById('preview-company').innerText = document.getElementById('company').value;
  document.getElementById('preview-job-title').innerText = document.getElementById('job-title').value;
  document.getElementById('preview-job-duration').innerText = document.getElementById('job-duration').value;
  document.getElementById('preview-job-description').innerText = document.getElementById('job-description').value;
  document.getElementById('preview-project-title').innerText = document.getElementById('project-title').value;
  document.getElementById('preview-project-description').innerText = document.getElementById('project-description').value;
  document.getElementById('preview-certification').innerText = document.getElementById('certification').value;
  document.getElementById('preview-certification-year').innerText = document.getElementById('certification-year').value;

  // Populate skills and languages
  const skills = document.getElementById('skills').value.split(',').map(skill => skill.trim());
  const skillsList = document.getElementById('preview-skills');
  skillsList.innerHTML = skills.map(skill => `<li>${skill}</li>`).join('');

  const languages = document.getElementById('language').value.split(',').map(lang => lang.trim());
  const languagesList = document.getElementById('preview-languages');
  languagesList.innerHTML = languages.map(lang => `<li>${lang}</li>`).join('');

  // Show the preview
  document.getElementById('resume-preview').style.display = 'block';
}

// Print/Download PDF
function printResume() {
  window.print();
}
 // Save form data to localStorage
 function saveFormData() {
    const formData = {};
    const inputs = document.querySelectorAll('#resume-form input, #resume-form textarea');

    inputs.forEach(input => {
      formData[input.id] = input.value;
    });

    // Save photo preview
    const photoPreview = document.getElementById('preview-photo').src;
    if (photoPreview !== '#') {
      formData['photo'] = photoPreview;
    }

    localStorage.setItem('resumeData', JSON.stringify(formData));
  }

  // Load saved form data
  function loadFormData() {
    const savedData = localStorage.getItem('resumeData');
    if (savedData) {
      const formData = JSON.parse(savedData);

      Object.keys(formData).forEach(key => {
        const input = document.getElementById(key);
        if (input) {
          input.value = formData[key];
        }
      });

      // Load photo preview
      if (formData['photo']) {
        document.getElementById('preview-photo').src = formData['photo'];
        document.getElementById('preview-photo').style.display = 'block';
        document.getElementById('preview-photo-display').src = formData['photo'];
      }
    }
  }

  // Attach event listeners to auto-save
  document.querySelectorAll('#resume-form input, #resume-form textarea').forEach(input => {
    input.addEventListener('input', saveFormData);
  });

  // Load saved data when the page loads
  window.addEventListener('load', loadFormData);